package com.cg.customer.message;

public class CustomerResponse {
	private String status;
	private Object data;
	
	public CustomerResponse(){
		
	}
	
	public CustomerResponse(String status, Object data){
		this.status = status;
		this.data = data;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
}

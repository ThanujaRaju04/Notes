package com.cg.customer.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.cg.customer.model.Customer;



@Repository
public class CustomerDaoImpl implements CustomerDao {
	  @Autowired
    private MongoTemplate mongoTemplate;
    
    @Override
    public Customer saveCustomer(Customer person) {
       mongoTemplate.save(person);
       return person;
    }
    @Override
    public List<Customer> getAllCustomer() {
       return mongoTemplate.findAll(Customer.class);
    }
    
    
    
    @Override
    public List<Customer> getAllCustomerPaginated(int pageNumber, int pageSize) {
       Query query = new Query();
       query.skip(pageNumber * pageSize);
       query.limit(pageSize);
       return mongoTemplate.find(query, Customer.class);
    }
    @Override
    public Customer findOneByName(String name) {
       Query query = new Query();
       query.addCriteria(Criteria.where("name").is(name));
       return mongoTemplate.findOne(query, Customer.class);
    }
    @Override
    public List<Customer> findByName(String name) {
       Query query = new Query();
       query.addCriteria(Criteria.where("name").is(name));
       return mongoTemplate.find(query, Customer.class);
    }
    
    
    @Override
    public List<Customer> findByAgeRange(int lowerBound, int upperBound) {
       Query query = new Query();
       query.addCriteria(Criteria.where("age").gt(lowerBound)
               .andOperator(Criteria.where("age").lt(upperBound)));
       return mongoTemplate.find(query, Customer.class);
    }
   
    @Override
    public void updateMultiplePersonAge() {
       Query query = new Query();
       Update update = new Update().inc("age", 1);
       mongoTemplate.findAndModify(query, update, Customer.class);;
    }
    @Override
    public Customer updateOneCustomer(Customer person) {
       mongoTemplate.save(person);
       return person;
    }
    @Override
    public void deleteCustomer(Customer person) {
       mongoTemplate.remove(person);
    }
}
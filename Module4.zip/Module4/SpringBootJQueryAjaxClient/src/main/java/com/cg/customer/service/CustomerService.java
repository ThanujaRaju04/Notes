package com.cg.customer.service;

import java.util.List;

import com.cg.customer.model.Customer;

public interface CustomerService {
	public Customer create(Customer customer);
	public List<Customer> getAll();
	public void deleteCustomer(Customer customer);
}

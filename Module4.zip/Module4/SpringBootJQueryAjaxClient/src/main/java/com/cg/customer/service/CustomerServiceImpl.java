package com.cg.customer.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;





import com.cg.customer.dao.CustomerDao;
import com.cg.customer.model.Customer;


@Service
public class CustomerServiceImpl implements CustomerService{
   
	@Autowired
	private CustomerDao customerRepository;
	
	//Create operation
	@Override
	public Customer create(Customer customer) {
		return customerRepository.saveCustomer(customer);
	}
	//Retrieve operation
	@Override
	public List<Customer> getAll(){
		return customerRepository.getAllCustomer();
	}
	@Override
	public void deleteCustomer(Customer customer)
	{
		customerRepository.deleteCustomer(customer);
	}
	
	
}
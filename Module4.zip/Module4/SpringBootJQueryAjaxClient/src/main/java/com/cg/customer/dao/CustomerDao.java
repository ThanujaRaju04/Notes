package com.cg.customer.dao;

import java.util.Date;
import java.util.List;

import com.cg.customer.model.Customer;



public interface CustomerDao {
   Customer saveCustomer(Customer customer);
   List<Customer> getAllCustomer();
   List<Customer> getAllCustomerPaginated(
      int pageNumber, int pageSize);
   Customer findOneByName(String name);
   List<Customer> findByName(String name);
  
   List<Customer> findByAgeRange(int lowerBound, int upperBound);
   
   void updateMultiplePersonAge();
   Customer updateOneCustomer(Customer customer);
   void deleteCustomer(Customer customer);
}
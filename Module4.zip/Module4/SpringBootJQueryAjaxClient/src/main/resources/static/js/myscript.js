
$( document ).ready(function() {
	
	
   $("#customerdelete").click(function(){
	    
	      alert(" Hello ");
	});
	// SUBMIT FORM
	$("#customerForm").submit(function(event) {
	// Prevent the form from submitting via the browser.
		event.preventDefault();
		ajaxPost();
	});
	// GET REQUEST
	$("#getAllCustomerId").click(function(event){
		event.preventDefault();
		ajaxGet();
	});
	// DO DELETE
	function ajaxDelete(){
		var id=$("#deletecustomer").attr("href");
		
		$.ajax({
			type : "GET",
			url : window.location + "api/person/delete/"+id,
			success: function(result){
				if(result.status == "Done"){
					$('#getResultDiv ul').empty();
					var custList = "";
					$.each(result.data, function(i, customer){
						var customer = (i+1)+"] -  Id = " + customer.id + ", firstname = " + customer.firstName + ", lastName = " + customer.lastName + ", Age ="+customer.age+"   <br>";
						$('#getResultDiv .list-group').append(customer)
			        });
					console.log("Success: ", result);
				}else{
					$("#getResultDiv").html("<strong>Error</strong>");
					console.log("Fail: ", result);
				}
			},
			error : function(e) {
				$("#getResultDiv").html("<strong>Error</strong>");
				console.log("ERROR: ", e);
			}
		});	
	}
	function ajaxGet(){
		$.ajax({
			type : "GET",
			url : window.location + "api/person/getAll",
			success: function(result){
				if(result.status == "Done"){
					$('#getResultDiv ul').empty();
					var custList = "";
					$.each(result.data, function(i, customer){
						var customer = (i+1)+"] -  Id = " + customer.id + ", firstname = " + customer.firstName + ", lastName = " + customer.lastName + ", Age ="+customer.age+"  <a id=\"customerdelete\" href=\"api/person/delete/"+customer.id+"\" > delete </a><br>";
						$('#getResultDiv .list-group').append(customer)
			        });
					console.log("Success: ", result);
				}else{
					$("#getResultDiv").html("<strong>Error</strong>");
					console.log("Fail: ", result);
				}
			},
			error : function(e) {
				$("#getResultDiv").html("<strong>Error</strong>");
				console.log("ERROR: ", e);
			}
		});	
	}
	
	function ajaxPost() {
        
		// PREPARE FORM DATA
		var formData = {
			firstName : $("#firstName").val(),
			lastName : $("#lastName").val(),
			age : $("#age").val()
		}

		// DO POST
		$.ajax({
					type : "POST",
					contentType : "application/json",
					url : window.location + "api/person/create",
					data : JSON.stringify(formData),
					dataType : 'json',
					success : function(result) {
						if (result.status == "Done") {
							$("#postResultDiv")
									.html(
											"<p style='background-color:#7FA7B0; color:white; padding:20px 20px 20px 20px'>"
													+ "Post Successfully! <br>"
													+ "---> Person's Info: FirstName = "
													+ result.data.firstName
													+ " ,LastName = "
													+ result.data.lastName
													+" , Age = "
													+result.data.age
													+ "</p>");
						} else {
							$("#postResultDiv").html(
									"<strong>Error</strong>");
						}
						console.log(result);
					},
					error : function(e) {
						alert("Error!")
						console.log("ERROR: ", e);
					}
				});

		// Reset FormData after Posting
		resetData();

	}

	function resetData() {
		$("#firstName").val("");
		$("#lastName").val("");
		$("#age").val("");
	}
})